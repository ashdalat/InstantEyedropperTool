Instant Eyeropper
---------------------------------------------
color detection tool

License notes
---------------------------------------------
Instant Eyeropper is distributed as Freeware. 
See also License agreement. 

For more information, please visit
http://instant-eyedropper.com/

---------------------------------------------
(c) SpiceBrains.com
